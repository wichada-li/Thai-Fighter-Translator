# Thai Fighter Translator — GitHub Pages build

Static, browser-only version. No server / Node runtime needed — works on GitHub Pages forever, no trial limits.

## Files
- `index.html` — the app (UI + logic wiring)
- `romanize.browser.js` — the romanizer engine, ported from `romanize.js` to run in the browser (no `fs`/`path`)
- `first_names.json`, `last_names.json`, `csv_word_dict.json` — dictionaries, fetched by the browser at load time

## How to deploy on GitHub Pages
1. Copy these 5 files into the root of your `wichada-li/Thai-Fighter-Translator` repo (replacing/adding alongside the existing files — you can keep `server.js`/`romanize.js`/etc. for local dev, they just won't be used on Pages).
2. Commit and push to `main`.
3. On GitHub: repo → **Settings** → **Pages** → under "Build and deployment", set Source = "Deploy from a branch", Branch = `main` / `root`.
4. Save. GitHub will give you a URL like `https://wichada-li.github.io/Thai-Fighter-Translator/` within a minute or two.

## What changed vs. the Railway version
- `romanize.js` used `fs.readFileSync` to load the 3 JSON dictionaries at require-time (Node-only). `romanize.browser.js` instead exposes `Romanizer.init({first, last, csv})`, called once the browser has `fetch()`-ed those JSON files.
- `index.html` used to `POST /api/translate` to `server.js`. It now calls `Romanizer.translateName(input)` directly in the browser — no backend needed.
- `server.js`, `Dockerfile`, `railpack.json`, `package.json` are no longer needed for the Pages deployment (kept only if you still want local/Node dev).
